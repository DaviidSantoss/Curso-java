package Testes;

import Temperatura.fahrenheit;

public class Principal {

    public static void main(String[] args) {

	fahrenheit f1 = new fahrenheit();

	f1.fahrenheitForCelcius(100.0);
    }

}
