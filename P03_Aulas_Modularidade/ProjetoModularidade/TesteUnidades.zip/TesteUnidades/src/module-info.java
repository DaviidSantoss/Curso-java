module app.teste {

    requires app.unidades;
}