package Temperatura;

public class fahrenheit {

    public void fahrenheitForCelcius(Double Fah) {

	Double c = (Fah - 32) / 1.8;

	System.out.println(Fah + " Em graus Celcius é: " + c);

    }

}
