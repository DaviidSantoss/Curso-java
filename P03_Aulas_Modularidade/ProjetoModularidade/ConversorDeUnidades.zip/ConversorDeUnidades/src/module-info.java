module app.unidades {

    exports Temperatura;

}